# Project 0

Web Programming with Python and JavaScript
Discription of my project:
	Here i have created a Website of containing 4 pages, this website is related to my Personal
	Career/CV my skills and team etc.
	all requirements are filled up with decent work!
